import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
    status: {
        backgroundColor: "#000000"
    }
})