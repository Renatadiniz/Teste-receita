import { StatusBar } from "react-native";
import { styles } from './styles'

const Statusbar = () => {
    <StatusBar style={styles.status} />
}

export default Statusbar;